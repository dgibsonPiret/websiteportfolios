GitHub Pages portfolio

Extract this ZIP, then upload index.html to the root of your GitHub repository. The file contains the latest portfolio and its scroll fade animation.
